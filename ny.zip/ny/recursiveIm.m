function Imx = recursiveIm(Sm, x, h)
%Imx = recursiveIm
% Input: Im (input value of I), x (output index desired), h (step size)
% Output: Imx (equation of Imx in terms of Im, b, y)
%
% Recursive algorithm
% Imx is dependent on Smx, and vice versa
% look at recursiveSm, for referenc

if x == 0
    % if incremental output index is 0, return the input Im value
    Imx = @(Im, b, y) Im;
    return;
end

tmp = @(Im, b, y) Im; % initialize Im tmp

% loop through the timesteps
for i = 1:x
    
    % need an expression of Sm
    sm = @(Im, b, y) recursiveSm(Sm, i - 1, h);
    tmp_i = @(Im, b, y) 1 + h*(b*sm(Im, b, y) - y);
    
    % applying the recursive formula of Ix
    tmp = @(Im, b, y) tmp(Im, b, y) * tmp_i(Im, b, y);
    
   
    
end

Imx = @(Im, b, y) tmp(Im, b, y);
return;

end

