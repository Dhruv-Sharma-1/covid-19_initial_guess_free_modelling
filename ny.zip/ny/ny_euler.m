%% New York Data Modelling

% Approximations using Euler's Method. Numerical solution to differential
% equations. 

% Updated from ny_updated.m

% NY Data
% cited: https://www1.nyc.gov/site/doh/covid/covid-19-data.page
filename = 'coronavirus-data-master/case-hosp-death.csv';
M = readtable(filename);

dates = M.DATE_OF_INTEREST;
Idata = M.CASE_COUNT;
Hdata = M.HOSPITALIZED_COUNT;
Rd_data = M.DEATH_COUNT;

Rc_data(1) = Rd_data(1);
for i=2:length(Rd_data)
   Rc_data(i) = sum(Rd_data(1:i)); 
end

Ic_data(1) = Idata(1);
for i=2:length(Idata)
   Ic_data(i) = sum(Idata(1:i)); 
end

% population 
% cited: https://worldpopulationreview.com/us-cities/new-york-city-ny-population
N = 1629000; % 8323340;

% N = S + I + R

Sdata(1) = N;
Sdata(2) = Sdata(1) - Idata(1);
for i = 3:length(dates)
    Sdata(i) = Sdata(i-1) - Idata(i-1); 
end

Sdata = Sdata.';



%% Differential Equations

n = 1; % number of discretizations

i = 1; % counter for data value
m = size(dates, 1);
  
% options set using optimset
es = 1/(10^10);
mfe = 10^6;
iter = 5000;
options = optimoptions('fsolve', 'Algorithm', 'levenberg-marquardt', ...
         'FunctionTolerance', es, 'StepTolerance', es); 

param_count = m-1;  


% recursive solution
% r = recursiveSm(Sm, n, h)
% eq1 = @(Sm, Im, b, y) r(Im, b, y) - Sm;
% eq1(100, Im, b, y)
syms b y Im

bmed = zeros(n, 1);
gmed = zeros(n, 1);


    
h = 1/n; % resultant time-step
dt = 1/n;
    
% array of all solutions, specific to each n
beta = zeros(param_count, 1); 
gamma = zeros(param_count, 1);
IMvals = zeros(param_count, 1);
cnt = 0;
    
for i = 1:m-1
        
        Sm1 = Sdata(i);
        Si1 = recursiveSm(Sm1, n, h);
  
        Ii1 = recursiveIm(Sm1, n, h);
    
        % Sm - Sm+1 = Idata,1
        eq1 = Sm1 - Si1(Im, b, y);
    
    
        Sm2 = Sdata(i+1);
        Si2 = recursiveSm(Sm2, n, h);
    
        Ii2 = recursiveIm(Sm2, n, h);
        II2 = recursiveIm(Sm1, 2*n, h);
     
        % equation that links the two Im+2
        %eq3 = Ii2(Im, b, y) - II2(Im, b, y);
    
        Im1 = Ii1(Im, b, y);
        % Sm+1 - Sm+2 = Idata,2
        eq2 =  Sm2 - subs(Si2(Im, b, y), Im, Im1);
    
        % Sm - Sm2 = Idata,1 + Idata,2
        SiI2 = recursiveSm(Sm1, 2*n, h);
        eq3 = Sm1 - SiI2(Im, b, y);
    
        EQ3 = @(a, B, Y) subs(eq3, [Im, b, y], [a, B, Y]);
    
        % the other two equations of daily new data, with only the unknown
    
        EQ1 = @(a, B, Y) subs(eq1, [Im, b, y], [a, B, Y]);
        EQ2 = @(a, B, Y) subs(eq2, [Im, b, y], [a, B, Y]);
    
        % initial search point
        b0 = (Idata(i) + 1)/(N*Ic_data(i+1));
        r0 = 2.5;
        y0 = b0/r0;
    
        init_points = [Ic_data(i), b0, y0];
    
        func_handle = @(x) solveSIR(x, {EQ1, EQ2, EQ3}, [Idata(i), Idata(i+1)]);
    
        sol = fsolve(func_handle, init_points, options);
     
        cnt = cnt + 1;
        beta(cnt) = sol(2);
        gamma(cnt) = sol(3);
        IMvals(cnt) = sol(1);
    
end

% for i = 1:m-1
%     
%         m_1 = i; % data value 1
%         m_2 = i+1; % data value 2
%         
%         % initial search point
%         y0 = 1/14;
%         r0 = 2.5;
%         b0 = r0 * y0;
%         init_points = [Ic_data(m_1), Ic_data(m_2), b0, y0];
%         
%         % creates the function handle with input values specific to data
%         func_handle = @(x) solver1020(x, [Sdata(m_1), Sdata(m_2)], dt, ...
%             {eqn1, eqn2}, [Idata(m_1), Idata(m_2)]);
%     
%         sol = fsolve(func_handle, init_points, options);
%         
%         % add solved values of parameters to a vector
%         cnt = cnt + 1;
%         beta(cnt) = sol(3);
%         gamma(cnt) = sol(4);
%         
% end

bmed = median(beta) * N;
gmed = median(gamma);
Imed = median(IMvals);

% plotting histogram of solutions
nb = 25;

figure(1);
histogram(beta, nb);
title('Histogram of \beta');
xlabel('Value of Parameter');    
ylabel('Count');


figure(2);
histogram(gamma, nb);
title('Histogram of \gamma');
xlabel('Value of Parameter');
ylabel('Count');
               




function f = solveSIR(x, eqn, Idata)
% function to implement the 4 equations used to solve for the parameters
% Im1, beta, gamma are unknowns
% eqn1 is derived by dS/dt, dI/dt, and I_new
% eqn2 is dervied by dR/dt, dI/dt, S+I+R = N

a = x(1);
B = x(2);
Y = x(3);

EQ1 = eqn{1};
EQ2 = eqn{2};
EQ3 = eqn{3};



f(1) = double(EQ1(a, B, Y)) - Idata(1);
f(2) = double(EQ2(a, B, Y)) - Idata(2);
f(3) = double(EQ3(a, B, Y)) - sum(Idata);


end