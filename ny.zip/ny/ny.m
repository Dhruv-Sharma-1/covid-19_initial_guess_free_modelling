%% COVID - 19

% Initial Guess Free Method for Parameter Estimation in COVID-19 Models


% NY Data
% cited: https://www1.nyc.gov/site/doh/covid/covid-19-data.page
filename = 'coronavirus-data-master/case-hosp-death.csv';
M = readtable(filename);

dates = M.DATE_OF_INTEREST;
Idata = M.CASE_COUNT;
Hdata = M.HOSPITALIZED_COUNT;
Rd_data = M.DEATH_COUNT;

% plot of the data, by date from March to June
figure(1);
plot(dates, Idata, 'b-', dates, Hdata, 'g-', dates, Rd_data, 'r-');
grid on
legend('Infectious Cases', 'Hospitalized Cases', 'Death Count');
xlabel('Date');
ylabel('Case Count');
title('New Cases Per Day For New York City [March - June]');


% this given data is time-series, of new cases per day
% S-I-R compartments are cumulative at each time t

Rc_data(1) = Rd_data(1);
for i=2:length(Rd_data)
   Rc_data(i) = sum(Rd_data(1:i)); 
end

Ic_data(1) = Idata(1);
for i=2:length(Idata)
   Ic_data(i) = sum(Idata(1:i)); 
end

% population 
% cited: https://worldpopulationreview.com/us-cities/new-york-city-ny-population
N = 8323340;

% N = S + I + R
Sdata = N - (Ic_data + Rc_data);

% plot of the SIR data by date
figure(2);
plot(dates, Ic_data, 'b-', dates, Rc_data, 'r-');
grid on;
legend('Infectious (I(t))', 'Removed (R(t))');
xlabel('Date');
ylabel('Case Count');
title('SIR Data for New York City [March - June]');



filename = 'coronavirus-data-master/deaths/probable-confirmed-dod.csv';
Md = readtable(filename);

dod = Md.DATE_OF_DEATH;
Rd_conf = Md.CONFIRMED_COUNT;
Rd_prob = Md.PROBABLE_COUNT;

figure(3);
plot(dod, Rd_conf, dod, Rd_prob + Rd_conf);
grid on;
legend('Confirmed Deaths', 'Expected Actual Deaths');
xlabel('Date');
ylabel('Count');
title('COVID-19 Death Count in New York City');


%% Parameter Estimation

m = size(dates);

% at each time t, use I(t), R(t), to calculate beta, gamma
for t=1:m
    % int(I)|0,t
    intI(t)= trapz(Ic_data(1:t));
    
    beta(t) = (-log(Sdata(t)/N)) / (intI(t));
    gamma(t) = Rc_data(t) / (intI(t));
    
end


% odefun for differential systems of SIR

tspan = 0:m-1;
y0 = [Sdata(1); Ic_data(1); Rc_data(1)];

% using median values just as test
bmed = double(median(beta(2:end)));
gmed = double(median(gamma(2:end)));

bmean = double(mean(beta(2:end)));
gmean = double(mean(gamma(2:end)));

bmax = double(max(beta(2:end)));
gmax = double(max(gamma(2:end)));

% SIR model using estimated paramters

b = bmean;
g = gmean;

SIR1 = @(S,I,R) -(b*S.*I);
SIR2 = @(S,I,R) (b*S.*I) - g*I;
SIR3 = @(S,I,R) g*I;

dSIR = @(S,I,R) [SIR1(S,I,R); SIR2(S,I,R); SIR3(S,I,R)];


[t, Y] = ode45(@(t,y) dSIR(y(1),y(2),y(3)), tspan, y0);

S_sol = Y(:, 1);
I_sol = Y(:, 2);
R_sol = Y(:, 3);

t = t(1:120);

% comparitive study plot
figure(4)
subplot(2, 1, 1);
plot(t, I_sol(1:120), t, Ic_data(1:120));
legend('Solution', 'Data');
title('I');
subplot(2, 1, 2);
plot(t, R_sol(1:120), t, Rc_data(1:120));
legend('Solution', 'Data');
title('R');

% function to plot multiple SIR solutions with various parameter values

% for i = 1:50
%     n = i+1;
%     
%     g = 1/30;
%     b = double(beta(n));
%     
%     [t, Y] = ode45(@(t,y) dSIR(y(1),y(2),y(3)), tspan, y0);
%     
%     S_sol = Y(:, 1);
%     I_sol = Y(:, 2);
%     R_sol = Y(:, 3);
% 
%     t = t(1:100);
% 
%     % comparitive study plot
%     figure(4+i);
%     subplot(2, 1, 1);
%     plot(t, I_sol(1:100), t, Ic_data(1:100));
%     legend('Solution', 'Data');
%     title('I');
%     subplot(2, 1, 2);
%     plot(t, R_sol(1:100), t, Rc_data(1:100));
%     legend('Solution', 'Data');
%     title('R');
% end





