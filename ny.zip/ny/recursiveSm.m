function Smx = recursiveSm(Sm, x, h)
% Smx = recursiveSm
% Input: Sm (input value of S), x (output index desired), h (step size)
% Output: Smx (equation of Smx in terms of Im, b, y)
%
% Recursive algorithm
% Smx is dependent on Imx, and vice versa
% look at recursiveIm, for reference

if x == 0
    % if incremental output index is 0, return the input Sm value
    Smx = @(Im, b, y) Sm;
    return;
end

Smx = Sm; % initialize Smx
tmp = @(Im, b, y) 1;

% expS = @(Im, b, y) 1 - h*b*Im;
% expI = @(Sm, b, y) 1 + h*(b*Sm - y);

for i = 1:x
    
    % expression of Im
    im = @(Im, b, y) recursiveIm(Sm, i-1, h);
    tmp_i = @(Im, b, y) 1 - h*b*im(Im, b, y);
    
    % applying the recursive formula of S
    tmp = @(Im, b, y) tmp(Im, b, y) * tmp_i(Im, b, y);
    

    
end

Smx = @(Im, b, y) Smx*tmp(Im, b, y);
return

end
