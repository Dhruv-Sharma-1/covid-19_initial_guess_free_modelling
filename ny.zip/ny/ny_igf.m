%% New York Data Modelling

% Approximations using Euler's Method. Numerical solution to differential
% equations. 

% Updated from ny_euler.m, ny.m

% NY Data
% cited: https://www1.nyc.gov/site/doh/covid/covid-19-data.page
filename = 'coronavirus-data-master/case-hosp-death.csv';
M = readtable(filename);

dates = M.DATE_OF_INTEREST;
Idata = M.CASE_COUNT;
Hdata = M.HOSPITALIZED_COUNT;
Rd_data = M.DEATH_COUNT;

Rc_data(1) = Rd_data(1);
for i=2:length(Rd_data)
   Rc_data(i) = sum(Rd_data(1:i)); 
end

Ic_data(1) = Idata(1);
for i=2:length(Idata)
   Ic_data(i) = sum(Idata(1:i)); 
end

% population 
% cited: https://worldpopulationreview.com/us-cities/new-york-city-ny-population
N = 1629000; %N = 8323340;

% N = S + I + R

Sdata(1) = N;
Sdata(2) = Sdata(1) - Idata(1);
for i = 3:length(dates)
    Sdata(i) = Sdata(i-1) - Idata(i-1); 
end

Sdata = Sdata.';

%% SIR Modelling

bmed = [0.1114, 0.0113, 0.0145, 0.0096, 0.0097, 0.0097];    % beta_n
gmed = [0.0716, 0.0333, 0.0526, 0.0877, 0.0877, 0.0877];    % gamma_n
Imed = 1.7760e+05;
Imed = 10;

cnt = length(bmed);

i = 6;
% evaluate parameter values

par0 = [bmed(i), gmed(i)];
func_handle = @(p) lsqError(p, Idata, N, Imed);
lb = [0, 0];
ub = [10, 10];

% search for optimal parameters
[p_i, res] = lsqnonlin(func_handle, par0, lb, ub);
    
bsol = p_i(1);
gsol = p_i(2);
    

% create figures and data values
m = size(Idata, 1);
n = 0;
dt = 1/8;

% tt = 0:(m-1);
tspan = 0:dt:(m-dt);
y0 = [N - Idata(1); Imed; 1];
% modification to data
z = zeros([1 n/2]);
Id = [z Idata.'];
Id = [Id z];
    
% SIR model using estimated paramters
b = bsol;
g = gsol;

SIR1 = @(S,I,R) (-b.*S.*I)/N;           % dS/dt
SIR2 = @(S,I,R) (b.*S.*I)/N - g.*I;     % dI/dt      
SIR3 = @(S,I,R) g.*I;                   % dR/dt

dSIR = @(S,I,R) [SIR1(S,I,R); SIR2(S,I,R); SIR3(S,I,R)];

Y = ode45(@(t,y) dSIR(y(1),y(2),y(3)), tspan, y0);

% S_sol = Y(:, 1);
% I_sol = Y(:, 2);
% R_sol = Y(:, 3);

tt = linspace(0, m-1, m);
S_sol = deval(Y, tt, 1);
I_sol = deval(Y, tt, 2);
R_sol = deval(Y, tt, 3);
    
S_del = zeros(size(S_sol));
S_del(1) = N - S_sol(1);
for i = 2:length(tt)
    S_del(i) = S_sol(i-1) - S_sol(i);
end

R_del = zeros(size(R_sol));
R_del(1) = 1;
for i = 2:length(tt)
    R_del(i) = R_sol(i) - R_sol(i-1);
end

I_del = zeros(size(I_sol));
I_del(1) = I_sol(1);
for i = 2:length(tt)
    I_del(i) = (I_sol(i) - I_sol(i-1)) + R_del(i);
end

I_output = zeros(size(Idata));
I_output(1) = Idata(1);
for d = 1:(length(Idata)-1)
    I_output(d) = I_del((d));
end

st = 10; % start point of data
% comparitive study plot
figure(1);
plot(tt, S_del, tt, Id, 'r*');
legend('Fitted SIR Model (Prediction)', 'Daily Reported Cases (Data)');
title('Parameter Fitting of SIR model to COVID-19 Data (New York)');
xlabel('Time (m/Day)');
ylabel('Population Count');

figure(2);
plot(tt, S_del, tt, Id, 'r-');
legend('Fitted SIR Model (Prediction)', 'Daily Reported Cases (Data)');
title('Parameter Fitting of SIR model to COVID-19 Data (New York)');
xlabel('Time (m/Day)');
ylabel('Population Count');

% calculate strength of fit
A = S_del;
B = Id;

R = corr2(A, B);
R2 = R.*R;




%% Function to calculate least squares error, b/w data and predicted model

function S = lsqError(par, Idata, N, Imed)

% Dataset
m = size(Idata, 1);

% extrapolating tspan 1 month before and after
dt = 1/8;
tspan = 0:dt:(m-dt);
y0 = [N - Idata(1), Imed, 1];

b = par(1);
g = par(2);

SIR1 = @(S,I,R) (-b.*S.*I)/N;           % dS/dt
SIR2 = @(S,I,R) (b.*S.*I)/N - g.*I;     % dI/dt
SIR3 = @(S,I,R) g.*I;                   % dR/dt

dSIR = @(S,I,R) [SIR1(S,I,R); SIR2(S,I,R); SIR3(S,I,R)];


Y = ode45(@(t,y) dSIR(y(1),y(2),y(3)), tspan, y0);

% S_sol = Y(:, 1);
% I_sol = Y(:, 2);
% R_sol = Y(:, 3);

tt = linspace(0, m-1, m);
S_sol = deval(Y, tt, 1);
I_sol = deval(Y, tt, 2);
R_sol = deval(Y, tt, 3);

S_del = zeros(size(S_sol));
S_del(1) = N - S_sol(1);
for i = 2:length(tt)
    S_del(i) = S_sol(i-1) - S_sol(i);
end

R_del = zeros(size(R_sol));
R_del(1) = 1;
for i = 2:length(tt)
    R_del(i) = R_sol(i) - R_sol(i-1);
end

I_del = zeros(size(I_sol));
I_del(1) = I_sol(1);
for i = 2:length(tt)
    I_del(i) = (I_sol(i) - I_sol(i-1)) + R_del(i);
end

S = zeros(size(Idata));

for d = 1:(length(Idata)-1)
    S(d) = S_del(d) - Idata(d); 
end

end
