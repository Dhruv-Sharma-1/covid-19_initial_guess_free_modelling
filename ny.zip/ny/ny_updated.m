%% New York Data Modelling

% Updated from ny.m

% NY Data
% cited: https://www1.nyc.gov/site/doh/covid/covid-19-data.page
filename = 'coronavirus-data-master/case-hosp-death.csv';
M = readtable(filename);

dates = M.DATE_OF_INTEREST;
Idata = M.CASE_COUNT;
Hdata = M.HOSPITALIZED_COUNT;
Rd_data = M.DEATH_COUNT;

Rc_data(1) = Rd_data(1);
for i=2:length(Rd_data)
   Rc_data(i) = sum(Rd_data(1:i)); 
end

Ic_data(1) = Idata(1);
for i=2:length(Idata)
   Ic_data(i) = sum(Idata(1:i)); 
end

% population 
% cited: https://worldpopulationreview.com/us-cities/new-york-city-ny-population
N = 8323340;

% N = S + I + R
Sdata = N - (Ic_data + Rc_data);

%% Parameter Estimation

m = size(dates);

cnt = 0;
% for every two time-step values, we can calculate parameter values
% for i = 2:m
%     %for j = i:m
%         % we ignore all indices that are equal since that doesnt provide us
%         % with new insight into the values
%         %if (i ~= j)
%             j = i - 1;
%             I = [Ic_data(i) Ic_data(j)];
%             S = [Sdata(i) Sdata(j)];
%             p = solveIS(I, S, N);
%             
%             % add these parameter solutions to a vector
%             cnt = cnt + 1;
%             beta(cnt) = p(1);
%             gamma(cnt) = p(2);
%             
%             %fprintf('Count: %d , %1.5f, %1.5f\n', cnt, p(1), p(2));
%     
%         
%     %end 
%     fprintf('%d, %d\n', i, m);
% end

% odefun for modelling an SIR differential systemS
n = 60;
tspan = 0:(m-1 + n);
y0 = [Sdata(1); Ic_data(1); Rc_data(1)];

% bmean = double(mean(beta));
% gmean = double(mean(gamma));


% SIR model using estimated paramters

b = 0.00000005;
g = 0.29;

SIR1 = @(S,I,R) -(b*S.*I);          % dS/dt
SIR2 = @(S,I,R) (b*S.*I) - g*I;     % dI/dt      
SIR3 = @(S,I,R) g*I;                % dR/dt

dSIR = @(S,I,R) [SIR1(S,I,R); SIR2(S,I,R); SIR3(S,I,R)];

[t, Y] = ode45(@(t,y) dSIR(y(1),y(2),y(3)), tspan, y0);

S_sol = Y(:, 1);
I_sol = Y(:, 2);
R_sol = Y(:, 3);

Isol_daily = zeros(size(I_sol));
Isol_daily(1) = I_sol(1);

for i = 2:length(I_sol)
   
    Isol_daily(i) = I_sol(i) - I_sol(i-1);
    
end

% modification to data
z = zeros([1 n]);
Id = [z Idata.'];

% comparitive study plot
figure(1);
plot(t, Isol_daily, t, Id);
legend('Solution', 'Data');
title('I');













function param = solveIS(I, S, N)
% function to solve for parameter values at each timestep
% I(S) = (gamma/beta)*ln(S/N) + (N-S)

syms b y

eqn1 = b*(I(1) + S(1) - N) == y*log(S(1)/N);
eqn2 = b*(I(2) + S(2) - N) == y*log(S(2)/N);
sol = solve([eqn1 eqn2], [b y]);

param = [sol.b sol.y];


end




